from django.core.management.base import BaseCommand, CommandError
from IAM.models import identity

class Command(BaseCommand):
    help = 'Saves each object in the identity table'

    def handle(self, **options):
        ids = identity.objects.all()
        for id in ids:
            user = id
            user.save() 