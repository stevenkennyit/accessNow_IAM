from django.contrib import admin

#from import_export import resources

from IAM.models import membership, entitlement, account, identity, business_rule


#Could be used to hide fields from admins
class identityAdmin(admin.ModelAdmin):
    list_display = ('emp_number', 'first_name', 'last_name', 'job_title', 'email', 'hire_date', 'active')

admin.site.register(identity, identityAdmin)


class accountAdmin(admin.ModelAdmin):
    list_display = ('username', 'owner', 'email', 'active')

admin.site.register(account, accountAdmin)


class entitlementAdmin(admin.ModelAdmin):
    list_display = ('dn', 'create_date')

admin.site.register(entitlement, entitlementAdmin)


class membershipAdmin(admin.ModelAdmin):
    list_display = ('id', 'account', 'entitlement', 'last_update', 'revoked')

admin.site.register(membership, membershipAdmin)


admin.site.register(business_rule)
#admin.site.site_header = 'accessNow'