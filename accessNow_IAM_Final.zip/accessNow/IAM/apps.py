from django.apps import AppConfig


class IamConfig(AppConfig):
    name = 'IAM'
