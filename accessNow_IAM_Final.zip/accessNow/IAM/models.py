from django.db import models
import datetime
import subprocess, sys

from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType

from django.db.models.signals import post_save


class identity(models.Model):
    DEPARTMENT_CHOICES = (
        ('Operations', 'Operations'),
        ('accessNow', 'accessNow'), #Choices for department field
        ('Marketing', 'Marketing'),
        ('Sales', 'Sales'),
        ('Management', 'Management'),
    )

    JOB_TITLE_CHOICES = (
        ('Senior Manager', 'Senior Manager'),
        ('Manager', 'Manager'), #Choices for job_title field
        ('Analyst', 'Analyst'),
        ('Intern', 'Intern'),
    )

    first_name = models.CharField(max_length=75)
    last_name = models.CharField(max_length=75)
    emp_number = models.CharField(max_length=75, default='')
    job_title = models.CharField(max_length=150, choices=JOB_TITLE_CHOICES)
    department = models.CharField(max_length=150, choices=DEPARTMENT_CHOICES)
    email = models.CharField(max_length=150)
    hire_date = models.DateField()
    end_date = models.DateField()
    last_update = models.DateField()
    active = models.BooleanField(default=False)
    is_manager = models.BooleanField(default=False)

    def __str__(self):
        return self.email #The default attribute to be displayed when viewing this type of object


class account(models.Model):
    owner = models.ForeignKey(identity, default='1', on_delete=models.CASCADE)
    username = models.CharField(max_length=21)
    first_name = models.CharField(max_length=75)
    last_name = models.CharField(max_length=75)
    job_title = models.CharField(max_length=150)
    department = models.CharField(max_length=150)
    email = models.CharField(max_length=150)
    active = models.BooleanField(default=False)
    is_manager = models.BooleanField(default=False)

    def __str__(self):#The default attribute to be displayed when viewing this type of object
        return self.username

def update_or_create_account(sender, **kwargs):
    account.objects.update_or_create(
        owner=kwargs['instance'],
        defaults={"username": kwargs['instance'].first_name + '.' + str(kwargs['instance'].id),
                  "owner": kwargs['instance'],
                  "first_name": kwargs['instance'].first_name,
                  "last_name": kwargs['instance'].last_name,
                  "job_title": kwargs['instance'].job_title,
                  "department": kwargs['instance'].department,
                  "email": kwargs['instance'].email,
                  "active": kwargs['instance'].active,
                  "is_manager": kwargs['instance'].is_manager})



class entitlement(models.Model):
    name = models.CharField(max_length=256) #samAccountName
    description = models.CharField(max_length=256) #description
    dn = models.CharField(max_length=256, default='') #DistinguishedName
    email = models.CharField(max_length=256) #mail
    create_date = models.DateField(default=datetime.date.today) #whenCreated
    last_update = models.DateField(default=datetime.date.today)
    #is_privileged = models.BooleanField(default=False, blank=True) #Controlled in app
    owner = models.ForeignKey(identity, default='1', on_delete=models.CASCADE, blank=True, null=True) #Controlled in app

    def __str__(self):
        return self.dn


class business_rule(models.Model):
    name = models.CharField(max_length=256)
    description = models.CharField(max_length=256)
    department = models.CharField(max_length=256) #This is the rule. Accounts that have a matching department will be granted the policy item
    create_date = models.DateField(default=datetime.date.today)
    is_active = models.BooleanField(default=False)
    provisions = models.ForeignKey(entitlement)

    def __str__(self):
        return self.department


class membership(models.Model):
    account = models.ForeignKey(account)
    entitlement = models.ForeignKey(entitlement)
    last_update = models.DateField(default=datetime.date.today)
    revoked = models.NullBooleanField(default=False)

    def __str__(self):
        return "Change Request: " + str(self.id)


def update_or_create_membership(sender, **kwargs):
    rule = business_rule.objects.filter(description=kwargs['instance'].department)
    print(kwargs['instance'].department)
    #print(rule)


# signal dispatcher/sender
post_save.connect(update_or_create_account, sender=identity)
post_save.connect(update_or_create_membership, sender=account)