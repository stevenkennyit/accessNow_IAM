﻿#Name: AD Module 
#V2
#Purpose: Will carry out actions in the connected application (Active Directory)
#Each 5 mins it will check the accounts then membership table for changes.
#If a change is found, it will make the appropriate changes to user objects in AD(and groups?)
#Assumptions: The module must be run every 60 seconds for the logic to be effective

$ACC_PATH = "Y:\AD_Groups.csv"
$DB_PATH = "C:\temp\accessNow\db.sqlite3"
$SERVER = "WIN-63PGA10P15S"

#$creds = Get-Credential yourrOrg.com\Administrator

Import-Module ActiveDirectory

#Importing the SQLite assemblies
Add-Type -Path "C:\Program Files\System.Data.SQLite\2010\bin\System.Data.SQLite.dll"

#Connect to DB
$con = New-Object -TypeName System.Data.SQLite.SQLiteConnection
$con.ConnectionString = "Data Source=$DB_PATH"
$con.Open()

#Gets current date
$date = (Get-Date)

#Get entitlement table from database
$sql = $con.CreateCommand()
$sql.CommandText = "SELECT * FROM IAM_entitlement"
$adapter = New-Object -TypeName System.Data.SQLite.SQLiteDataAdapter $sql
$data = New-Object System.Data.DataSet
[void]$adapter.Fill($data)

#Export account table to csv
$entitlements = $data.Tables
Remove-Item C:\temp\tmp_ents.csv -ErrorAction SilentlyContinue
foreach($e in $entitlements){
    $e | Export-Csv c:\temp\tmp_ents.csv -NoTypeInformation -Append
}

#Get account table from database
$sql = $con.CreateCommand()
$sql.CommandText = "SELECT * FROM IAM_account"
$adapter = New-Object -TypeName System.Data.SQLite.SQLiteDataAdapter $sql
$data = New-Object System.Data.DataSet
[void]$adapter.Fill($data)

#Export account table to csv
$accounts = $data.Tables
Remove-Item C:\temp\tmp_accs.csv -ErrorAction SilentlyContinue
foreach($a in $accounts){
    $a | Export-Csv c:\temp\tmp_accs.csv -NoTypeInformation -Append
}

#Get membership table from database
$sql = $con.CreateCommand()
$sql.CommandText = "SELECT * FROM IAM_membership"
$adapter = New-Object -TypeName System.Data.SQLite.SQLiteDataAdapter $sql
$data = New-Object System.Data.DataSet
[void]$adapter.Fill($data)

#Export membership table to csv
$memberships = $data.Tables
Remove-Item c:\temp\tmp_mems.csv -ErrorAction SilentlyContinue
foreach($m in $memberships){
    $m | Export-Csv c:\temp\tmp_mems.csv -NoTypeInformation -Append
}

#I now have the accounts and membership table from DB (And now entitlements)
$mems = Import-Csv c:\temp\tmp_mems.csv 
$accs = Import-Csv c:\temp\tmp_accs.csv 
$ents = Import-Csv C:\temp\tmp_ents.csv

#Let's import the AD_User.csv file (scheduled task for Server2008R2)
$AD_Users = Import-Csv "Y:\AD_Users.csv" -Delimiter ";"

#Get the key headers of accs and ad_users 
$props1 = $accs | gm -MemberType NoteProperty | select -expand Name | sort | % {"$_"} | ? {$_ -eq 'active' -or $_ -eq 'department' -or $_ -eq 'job_title' -or $_ -eq 'username' -or $_ -eq 'first_name' -or $_ -eq 'last_name' -or $_ -eq 'email'}
$props2 = $AD_Users | gm -MemberType NoteProperty | select -expand Name | sort | % {"$_"} | ? {$_ -eq 'active' -or $_ -eq 'department' -or $_ -eq 'job_title' -or $_ -eq 'username' -or $_ -eq 'first_name' -or $_ -eq 'last_name' -or $_ -eq 'email'}

if(Compare-Object $props1 $props2)
{
    throw "Headers do not match [$props1] [$props2]"
}
# pass the list of properties to Compare-Object
else
{
    $results = Compare-Object $accs $AD_Users -Property $props1 -IncludeEqual 
}

#SideIndicator notes:
# == means objects are equal
# => means no changes to target are needed
# <= means a change has occurred in accessNow and the AD object needs to be modified

#Get accounts that 
$results = $results | ? {$_.sideIndicator -eq '<='}

foreach($r in $results){
    $active = [boolean]$r.active #Convert to boolean

    if($AD_Users.username -match $r.username){
        Write-Host "Modifying: " $r.username -ForegroundColor Green
        Set-ADUser $r.username -GivenName $r.first_name -Surname $r.last_name -Description $r.department -Enabled $active -EmailAddress $r.email -Title $r.job_title -Server $SERVER -Credential $creds
    }
    else{
        Write-Host "Creating: " $r.username -ForegroundColor Cyan
        New-ADUser $r.username -DisplayName $r.username -GivenName $r.first_name -Surname $r.last_name -Description $r.department -Enabled $active -accountPassword (ConvertTo-SecureString -AsPlainText "Ch4nge_1_Passw0rd!" -Force) -OtherAttributes @{title=$r.job_title;mail=$r.email} -Server $SERVER -Credential $creds
    }
}

#Now let's import the AD_Memberships.csv file (scheduled task for Server2008R2-pending)
$AD_Membership = Import-Csv "Y:\AD_Memberships.csv"

#Membership will be a bit tricky... foreach membership object known to accessNow
foreach($m in $mems){
    if($ents.id -match $m.entitlement_id){
        #Write-Host "Value is present: " $m.entitlement_id

        #Get the entitlement name from the id (membership objects do not store the actual ent name, only the id. Same for account)
        $ent = $ents | ? {$_.id -match $m.entitlement_id}

        #Get the account username from the id
        $acc = $accs | ? {$_.id -match $m.account_id}

        #Add membership where it does not exist in AD_Membership 
        if($AD_Membership.group -match $ent.dn -and $AD_Membership.user -match $acc.username){
            Write-Host "User" $acc.username "already member of" $ent.dn -ForegroundColor Green
        }
        else{
            Write-Host "Adding" $acc.username "to" $ent.dn -ForegroundColor Cyan
            Add-ADGroupMember -Identity $ent.dn -Members $acc.username -Server $SERVER -Credential $creds
        }
        
        #Make change to target 
        #write-host "Adding " $acc.username " to " $ent.name
        #Add-ADGroupMember -Identity $ent.name -Members $acc.username -Server $SERVER -Credential $creds

        
    }
    
}