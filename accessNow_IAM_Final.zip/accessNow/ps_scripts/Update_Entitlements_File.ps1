﻿#Update_Entitlements_File
#V1
#Date: 27-Jun-2017

$path = 'C:\users\Public\'
$file = 'entitlements.csv'
$fullPath = $path + $file

if (!(Test-Path $fullPath)){
    Get-ADGroup -Filter * -Properties samAccountName, description, DistinguishedName, mail, whenCreated, whenChanged | select samAccountName, description, DistinguishedName, mail, whenCreated, whenChanged | Export-Csv $fullPath -NoTypeInformation -Append -Force -Delimiter ";"
}
else{
    Remove-Item $fullPath
    Get-ADGroup -Filter * -Properties samAccountName, description, DistinguishedName, mail, whenCreated, whenChanged | select samAccountName, description, DistinguishedName, mail, whenCreated, whenChanged | Export-Csv $fullPath -NoTypeInformation -Append -Force -Delimiter ";"
}