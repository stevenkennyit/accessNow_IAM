﻿#Title: Modded HR_Module for entitlement module
#Author: Steven Kenny
#Date: 30/06/2017
#The script will run every 30 seconds.
#If the file has been modified in the last 30 seconds then compare each row to the correspondning record in identity table


$ENT_PATH = "Y:\AD_Groups.csv"
$DB_PATH = "C:\Temp\project_testing\mysite\db.sqlite3"

#Importing the SQLite assemblies
Add-Type -Path "C:\Program Files\System.Data.SQLite\2010\bin\System.Data.SQLite.dll"

#Check if exists then gets meta data of file
$lastUpdate = (Get-ChildItem $ENT_PATH).LastWriteTime

#Gets current date
$date = (Get-Date)

if($lastUpdate -lt $date.AddSeconds(-30)){#####Changed the logic for testing must change "-lt" back to "-gt"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    #For testing, will remove later :)
    Write-Host "We've got some changes" -ForegroundColor DarkGreen

    #Connect to DB
    $con = New-Object -TypeName System.Data.SQLite.SQLiteConnection
    $con.ConnectionString = "Data Source=$DB_PATH"
    $con.Open()

    #Import HR feed
    $feed = Import-Csv $ENT_PATH -Delimiter ";" -ErrorAction SilentlyContinue

    foreach($f in $feed){
        #$f.samAccountName
        $samAccountName = "'" + $f.samAccountName + "'"
        $desc = "'" + $f.description + "'"
        $dn = "'" + $f.DistinguishedName + "'"
        $mail = "'" + $f.mail + "'"
        $whenCreated = "'" + $f.whenCreated + "'"
        $whenChanged = "'" + (Get-Date $f.whenChanged -Format "yyyy-MM-dd") + "'"
        #$is_privileged = $true
        #$owner = ""

        #Check to see if user exists in DB (identifier is mail but it will be empNo)
        $sql = $con.CreateCommand()
        $sql.CommandText = "SELECT * FROM entitlements_entitlement where name = $samAccountName"
        $adapter = New-Object -TypeName System.Data.SQLite.SQLiteDataAdapter $sql
        $data = New-Object System.Data.DataSet
        [void]$adapter.Fill($data)

        #Export the query results to csv
        $table = $data.Tables
        foreach($t in $table){
            $t | Export-Csv c:\temp\tmp_ids.csv -NoTypeInformation -Append
        }

        #Import csv to array and delete csv
        Remove-Variable ent_check #-ErrorAction SilentlyContinue
        $ent_check = Import-Csv c:\temp\tmp_ids.csv
        Remove-Item c:\temp\tmp_ids.csv

        #If id_check is not null then update identity
        if($ent_check -ne $null){
            foreach($ent in $ent_check){
                Write-Host "Updating entitlement:" $ent.name -ForegroundColor DarkMagenta

                $sql = $con.CreateCommand()
                $sql.CommandText = "UPDATE entitlements_entitlement SET name = $samAccountName, description = $desc, dn = $dn, email = $mail, create_date = $whenCreated, last_update = $whenChanged WHERE name = $samAccountName"
                $adapter = New-Object -TypeName System.Data.SQLite.SQLiteDataAdapter $sql
                $data = New-Object System.Data.DataSet
                [void]$adapter.Fill($data)
            }
        }

        #If id_check is null then we'll create the record
        elseif($ent_check -eq $null){
            Write-Host "Creating entitlement:" $samAccountName -ForegroundColor Green

            $sql = $con.CreateCommand()
            $sql.CommandText = "INSERT INTO entitlements_entitlement (name, description, dn, email, create_date, last_update) VALUES ($samAccountName, $desc, $dn, $mail, $whenCreated, $whenChanged);"
            $adapter = New-Object -TypeName System.Data.SQLite.SQLiteDataAdapter $sql
            $data = New-Object System.Data.DataSet
            [void]$adapter.Fill($data)
        }
    }
}

else{
    Write-Host "No changes detected" -ForegroundColor Green
}

#echo "from identities.models import identity; i = identity.objects.all().count(); print c" | python manage.py shell

#from blog.models import Blog
#b = Blog(name='Beatles Blog', tagline='All the latest Beatles news.')
#b.save()
