﻿#Update_Entitlements_File
#V1
#Date: 27-Jun-2017

$path = 'C:\users\Public\'
$file = 'AD_Groups.csv'
$fullPath = $path + $file

Remove-Item $fullPath -ErrorAction SilentlyContinue
Get-ADGroup -Filter * -Properties samAccountName, description, DistinguishedName, mail, whenCreated, whenChanged | select samAccountName, description, DistinguishedName, mail, whenCreated, whenChanged | Export-Csv $fullPath -NoTypeInformation -Append -Force -Delimiter ";"
