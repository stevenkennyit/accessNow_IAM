﻿#Update_Accounts_File
#V1
#Date: 29-Jul-2017

Import-Module ActiveDirectory

$path = 'C:\users\Public\'
$file = 'AD_Users.csv'
$fullPath = $path + $file

Remove-Item $fullPath -ErrorAction SilentlyContinue
Get-ADUser -Filter * -Properties samAccountName, givenName, Surname, title, description, mail, enabled | select @{name="username";expression={$_.samAccountName}}, @{name="email";expression={$_.mail}}, @{name="first_name";expression={$_.givenName}}, @{name="last_name";expression={$_.Surname}},@{name="job_title";expression={$_.title}}, @{name="department";expression={$_.description}}, @{name="active";expression={$_.enabled}} | Export-Csv $fullPath -NoTypeInformation -Append -Force -Delimiter ";"

