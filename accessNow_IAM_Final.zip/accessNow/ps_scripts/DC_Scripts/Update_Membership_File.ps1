﻿#Update_Membership_File 

#Write membership and user function
function fWriteMems {
    $item = "" | select User, Group
    $item.User = $u.samAccountName
    $item.Group = $_ 
    $item | Export-Csv C:\Users\Public\AD_Memberships.csv -NoTypeInformation -Append
}

Remove-Item C:\Users\Public\AD_Memberships.csv -ErrorAction SilentlyContinue

$users = Get-ADUser -Filter * -Properties memberOf, samAccountName | select memberOf, samAccountName

foreach($u in $users){
    $u.memberOf | % {fWriteMems}
    
}

#$a = Read-Host "Ready?"