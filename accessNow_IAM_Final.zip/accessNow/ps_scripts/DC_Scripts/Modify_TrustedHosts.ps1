﻿Get-Item -Path WSMan:localhostClientTrustedHosts

Get-WSManInstance -ResourceURI winrm/config

$hosts = 'MCLUHAN-PC'
Set-WSManInstance -ResourceURI winrm/config/client -ValueSet @{TrustedHosts=$hosts}