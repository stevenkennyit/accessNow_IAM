﻿#Title: HR_Module
#Author: Steven Kenny
#Date: 30/06/2017
#The script will run every 30 seconds.
#If the file has been modified in the last 30 seconds then compare each row to the correspondning record in identity table


$HR_PATH = "c:\temp\HR_Feed.csv"
$DB_PATH = "C:\temp\accessNow\db.sqlite3"

#Importing the SQLite assemblies
Add-Type -Path "C:\Program Files\System.Data.SQLite\2010\bin\System.Data.SQLite.dll"

#Gets meta data of file
$lastUpdate = (Get-ChildItem $HR_PATH).LastWriteTime

#Gets current date
$date = (Get-Date)

if($lastUpdate -lt $date.AddSeconds(-30)){#####Changed the logic for testing must change "-lt" back to "-gt"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    #For testing, will remove later :)
    Write-Host "We've got some changes" -ForegroundColor DarkGreen

    #Import the HR feed file
    $feed = Import-Csv $HR_PATH

    #Connect to DB
    $con = New-Object -TypeName System.Data.SQLite.SQLiteConnection
    $con.ConnectionString = "Data Source=$DB_PATH"
    $con.Open()

    #Import HR feed
    $feed = Import-Csv $HR_PATH

    foreach($f in $feed){
        $first = "'" + $f.first_name + "'"
        $last = "'" + $f.Last_Name + "'"
        $empNo = "'" + $f.empNumber + "'"
        $job = "'" + $f.job_title + "'"
        $dept = "'" + $f.dept + "'"
        $mail = "'" + $f.email + "'"
        $hire = "'" + (Get-Date -format "yyyy-MM-dd") + "'"
        $end = "'" + (Get-Date -format "yyyy-MM-dd") + "'"
        $upd = "'" + (Get-Date -format "yyyy-MM-dd") + "'"
        $active = "'" + $f.active + "'"
        $is_mgr = "'" + $f.is_manager + "'"

        #Check to see if user exists in DB (identifier is mail but it will be empNo)
        $sql = $con.CreateCommand()
        $sql.CommandText = "SELECT * FROM IAM_identity where emp_Number = $empNo"
        $adapter = New-Object -TypeName System.Data.SQLite.SQLiteDataAdapter $sql
        $data = New-Object System.Data.DataSet
        [void]$adapter.Fill($data)

        #Export the query results to csv
        $table = $data.Tables
        foreach($t in $table){
            $t | Export-Csv c:\temp\tmp_ids.csv -NoTypeInformation -Append
        }

        #Import csv to array and delete csv
        Remove-Variable id_check -ErrorAction SilentlyContinue
        $id_check = Import-Csv c:\temp\tmp_ids.csv
        Remove-Item c:\temp\tmp_ids.csv -ErrorAction SilentlyContinue

        #If id_check is not null then update identity
        if($id_check -ne $null){
            Write-Host "User exists. Update identity" -ForegroundColor Green

            #Update
            $sql = $con.CreateCommand()
            $sql.CommandText = "UPDATE IAM_identity SET last_name = $last, first_name = $first, job_title = $job, department = $dept, emp_Number = $empNo, email = $mail, last_update = $upd WHERE emp_Number = $empNo"
            $adapter = New-Object -TypeName System.Data.SQLite.SQLiteDataAdapter $sql
            $data = New-Object System.Data.DataSet
            [void]$adapter.Fill($data)
        }

        #If id_check is null then we'll create the record
        elseif($id_check -eq $null){
            Write-Host "Does not exist. Create identity" -ForegroundColor Green

            #Create
            $sql = $con.CreateCommand()
            $sql.CommandText = "INSERT INTO IAM_identity (first_name, last_name, emp_Number, job_title, department, email, hire_date, end_date, active, is_manager, last_update) VALUES ($first, $last, $empNo, $job, $dept, $mail, $hire, $end, $active, $is_mgr, $upd);"
            $adapter = New-Object -TypeName System.Data.SQLite.SQLiteDataAdapter $sql
            $data = New-Object System.Data.DataSet
            [void]$adapter.Fill($data)
        }
    }
}

else{
    Write-Host "No changes detected" -ForegroundColor Green
}

Write-Host "Saving objects using Django methods" -ForegroundColor red
python C:\temp\accessNow\manage.py save_identities