﻿$DB_PATH = "C:\Users\McLuhan\Google Drive\Project\testing\mysite\mysite\db.sqlite3"

#Importing the SQLite assemblies
Add-Type -Path "C:\Program Files\System.Data.SQLite\2010\bin\System.Data.SQLite.dll"

#Connect to DB
$con = New-Object -TypeName System.Data.SQLite.SQLiteConnection
$con.ConnectionString = "Data Source=$DB_PATH"
$con.Open()

#Create query object and get data
$sql = $con.CreateCommand()
$sql.CommandText = "SELECT * FROM identities_identity"
$adapter = New-Object -TypeName System.Data.SQLite.SQLiteDataAdapter $sql
$data = New-Object System.Data.DataSet
[void]$adapter.Fill($data)


#Store query result in table variable
$table = $data.Tables 

#Export using loop
foreach($t in $table){
    $t | Export-Csv c:\temp\test3.csv -NoTypeInformation -Append 
}