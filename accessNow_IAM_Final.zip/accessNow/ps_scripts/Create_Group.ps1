﻿#Create_Group
#V1
#Date: 27-Jun-2017

New-ADGroup -Name "Management" -SamAccountName Management -GroupCategory Security -GroupScope Global -DisplayName "Management" -Path "OU=Groups,OU=EMEA,DC=yourrOrg,DC=com" -Description "Members of this group are Management staff"